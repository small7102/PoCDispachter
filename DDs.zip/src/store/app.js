// import { getGroupList, getMsList } from '@/sdkJs/webDispatch-sdk.js'
import { getMsList, getGroupList } from '@/sdkJs/webDispatch-sdk.js'
// import { getGroupList } from '@/sdkJs/getServer'
import { getChildArrayList } from '@/utils/dom'

const SET_GROUP_LIST = 'SET_GROUP_LIST'
const SET_MS_LIST = 'SET_MS_LIST'

export default {
  state: {
    groupList: [],
    msList: []
  },
  getters: {
    groupList: state => state.groupList,
    msList: state => state.msList
  },
  mutations: {
    [SET_GROUP_LIST] (state, list) {
      state.groupList = list
    },
    [SET_MS_LIST] (state, list) {
      state.msList = list
    }
  },
  actions: {
    getGroupsList ({ commit, dispatch }) {
      return new Promise((resolve, reject) => {
        getGroupList(res => {
          console.log(res)
          if (res && res.code === '0') {
            // 获取父群主
            let list = res.list.filter(item => {
              return item.fid === '0'
            })

            const resList = getChildArrayList(res.list, list)
            // commit('SET_GROUP_LIST', resList)
            resolve(resList)
          }
        })
      })
    },
    _getMsList ({ dispatch, commit, state }, {list, index, type = 'parent', cIndex = 0}) {
      return new Promise((resolve, reject) => {
        getMsList(list[index].gid, res => {
          if (res && res.code === '0') {
            let online = res.list.filter(item => { // 筛选上线数组
              return item.online === '1'
            })

            list[index].numString = `[${online.length}/${res.list.length}]`
            list[index].memberList = res.list

            if (type === 'parent') {
              commit('SET_GROUP_LIST', list)
            } else {
              console.log(index)
              state.groupList[cIndex].child[index] = list
              commit('SET_GROUP_LIST', state.groupList)
            }
            if (index === list.length - 1) {
              index = null
              resolve()
              return
            }
            index++
            dispatch('_getMsList', {list, index})
          }
        })
      })
    }
  }
}
