<template>
  <div class="header-bar-wrap">
    <div class="top flex align-center">
      <img src="../../../assets/kirisun.png" alt="Poc语音调度系统" class="logo">
      <span>Poc语音调度系统</span>
    </div>
    <div class="bottom flex align-center">
      <div class="item b-item">
        欢迎0003[IOS Test]登陆
      </div>
      <div class="item status flex-item">
        状态
      </div>
      <div class="item b-item">
        时间/信号
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HeaderBar'
}
</script>

<style lang="stylus" scoped>
  @import '../../../assets/styles/variable.styl'

  .top
    vertical-align middle
    height 40px
    padding 0 20px
    span
      font-size $font-size-large-x
      color $color-theme-weight
      font-weight bold
      line-height 40px
      padding-left 10px
  .bottom
    padding 0 20px
    height 40px
    line-height 40px
    overflow hidden
    background $color-theme-light
    color #0b247c
    .status
      text-align center
    .item
      font-size 18px
      color $color-theme-weight
    .b-item
      font-size 14px
</style>
