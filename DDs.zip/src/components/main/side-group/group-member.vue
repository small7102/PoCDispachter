<template>
  <transition name="slide">
    <div class="member-wrap">
      <ul>
        <li v-for="(item, index) in list" class="flex between" :key="index" @click.stop="selecItem(item, index)">
          <div class="left flex align-center">
            <img :src="iconImg(item.type, item.online)" alt="">
            <span class="name">{{item.name}}</span>
          </div>
          <div class="right">
            <i-icon type="md-mic" color='#4990d7'/>
            <i-icon type="md-text" color='#4990d7'/>
          </div>
        </li>
      </ul>
    </div>
  </transition>
</template>

<script>
import { Icon } from 'iview'
// import { mapGetters } from 'vuex'

export default {
  name: 'MemberList',
  components: {
    'i-icon': Icon
  },
  props: {
    childIndex: Number,
    parentIndex: Number,
    list: Array
  },
  mounted () {
  },
  methods: {
    selecItem () {
    },
    iconImg (type, online) {
      let url = ''

      switch (type) {
        case '20':
          url = this.getOnlineImg('Dispatcher', online)
          break
        case '10':
          url = this.getOnlineImg('App', online)
          break
        default:
          url = this.getOnlineImg('Poc', online)
          break
      }

      return url
    },
    getOnlineImg (iconName, online) {
      let imgName = online === '0' ? `outline${iconName}` : iconName
      let url = require(`../../../assets/device-icon/${imgName}.png`)

      return url
    }
  }
}
</script>

<style lang="stylus" scoped>
  .member-wrap
    overflow hidden
    li
      &:hover
        background #e5f3ff
    .left
      padding-left 20px
      span
        font-size 14px
        img
          display block
          width 20px
          margin-right 10px
    .right
      padding-right 20px
  .slide-enter-active, .slide-leave-active
    transition all .2s ease
  .slide-enter
    transform: translateX(200px)
  .slide-leave-to
    transform: translateX(-200px)
</style>
