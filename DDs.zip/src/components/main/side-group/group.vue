<template>
    <div class="group-list-wrap scroll-bar">
        <!-- <group-menu :groupList="groupList"></group-menu> -->
        <ul>
            <li v-for="(item) in groupList"
                :key="item.gid"
                class="parent-item"
                :class="{active: item.active}"
                @click="_toggleChildList(groupList, item)"
                >
                <div class="item-info">
                  <i-icon type="ios-arrow-forward" size="20"/>
                  <span class="name">{{item.name}}</span>
                  <span class="num">{{item.numString}}</span>
                </div>
                <group-sub v-if="item.active" :list='item.child'></group-sub>
                <member-list :list='item.memberList' v-if="item.active"/>
            </li>
        </ul>
    </div>
</template>

<script>
import { getGroupList, getMsList } from '@/sdkJs/webDispatch-sdk.js'
import GroupSub from './group-sub-list'
import MemberList from './group-member'
import { Icon } from 'iview'
import { toggleChildList } from '@/utils/dom'

export default {
  name: 'GroupList',
  components: {
    GroupSub,
    MemberList,
    'i-icon': Icon
  },
  data () {
    return {
      parentGroupList: []
    }
  },
  computed: {
    groupList () {
      let groupList = this.$store.getters.groupList
      console.log(groupList)
      return groupList
    }
  },
  created () {
    // this._getGroupList()
    this.itemIndex = 0
    this.parentIndex = 0
  },
  mounted () {
    this.$store.dispatch('getGroupsList').then((list) => {
      this.$store.dispatch('_getMsList', {list, index: this.parentIndex}).then(() => {
        // list.forEach(item => {
        //   this.$store.dispatch('_getMsList', {list: item.child, index: this.itemIndex, type: 'child'})
        // })
      })
    })
  },
  methods: {
    _toggleChildList (list, item) {
      toggleChildList(list, item)
    },
    _getGroupList () {
      getGroupList(res => {
        console.log(res)
        if (res && res.code === '0') {
          // 获取父群主
          let list = res.list.filter(item => {
            return item.fid === '0'
          })

          this._subListItem(list, this.parentIndex).then(() => {
            this.parentGroupList = this._getChildArrayList(res.list, list)
            console.log(this.parentGroupList)
            this.$store.commit('SET_GROUP_LIST', this.parentGroupList)
          })

          // this.parentGroupList = this._getChildArrayList(res.list, list)
        }
      })
    },
    _getChildArrayList (list, parentlist) {
      if (!list) return
      if (!parentlist) return

      const res = parentlist.map((parentitem, index) => {
        const childList = list.filter(childitem => { // 筛选群组列表
          if (childitem.fid === parentitem.gid) childitem.active = false // 默认闭合
          return childitem.fid === parentitem.gid
        })

        console.log(childList)
        // this._subListItem(childList, this.itemIndex)
        // console.log(childList)

        // // let all = childList.length
        // // let online = 0

        if (!index) parentitem.active = true // 第一个展开
        parentitem.child = childList
        // parentitem.numString = '0'

        return parentitem
      })

      console.log(res)
      return res
    },
    _subListItem (list, index) {
      if (!list.length) return
      return new Promise((resolve, reject) => {
        this.getSubItem(list, index)
        resolve()
      })
    },
    getSubItem (list, index) {
      getMsList(list[index].gid, res => {
        console.log(res)
        if (res && res.code === '0') {
          let online = res.list.filter(item => { // 筛选上线数组
            return item.online === '1'
          })

          list[index].numString = `[${online.length}/${res.list.length}]`
          list[index].memberList = res.list

          if (index === list.length - 1) return
          index++
          this.getSubItem(list, index)
        }
      })
    }
  }
}
</script>

<style lang="stylus" scoped>
  .group-list-wrap
    padding 10px
    height 100%
    overflow-y auto
    background #ffffff
    ul li
      height 34px
      line-height 34px
      font-size 16px
      cursor pointer
      transition all 0.1s
      &.active
        i
          transform rotate(90deg)
      .item-info
        font-size 16px
        &:hover
          color #1a4687
    .name,.num
      padding-left 5px
</style>
