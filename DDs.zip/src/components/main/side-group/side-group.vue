<template>
    <div class="group-list-wrap scroll-bar">
        <!-- <group-menu :groupList="groupList"></group-menu> -->
        <ul>
            <li v-for="(item, index) in groupList"
                :key="item.gid"
                class="parent-item"
                :class="{active: item.active}"
                @click="toggleChildList(item)"
                >
                <div class="item-info">
                  <i-icon type="ios-arrow-forward" size="20"/>
                  <span class="name">{{item.name}}</span>
                  <span class="num">{{item.numString}}</span>
                </div>
                <group-sub v-if="item.active" :childIndex="index"></group-sub>
            </li>
        </ul>
    </div>
</template>

<script>
import { getGroupList, getMsList } from '@/sdkJs/webDispatch-sdk.js'
import GroupSub from './group-sub-list'
import { Icon } from 'iview'

export default {
  name: 'GroupList',
  components: {
    GroupSub,
    'i-icon': Icon
  },
  data () {
    return {
      parentGroupList: [],
      itemIndex: 0
    }
  },
  computed: {
    groupList () {
      let store = this.$store.getters
      return store.groupList
    }
  },
  mounted () {
    this._getGroupList()
  },
  methods: {
    _getGroupList () {
      getGroupList(res => {
        if (res && res.code === '0') {
          // 获取父群主
          let list = res.list.filter(item => {
            return item.fid === '0'
          })

          this._subListItem(list)
          console.log(list)

          this.parentGroupList = this._getChildArrayList(res.list, list)
          this.$store.commit('SET_GROUP_LIST', this.parentGroupList)
        }
      })
    },
    _getChildArrayList (list, parentlist) {
      if (!list) return
      if (!parentlist) return

      const res = parentlist.map((parentitem, index) => {
        const childList = list.filter(childitem => { // 筛选群组列表
          if (childitem.fid === parentitem.gid) childitem.active = false // 默认闭合
          return childitem.fid === parentitem.gid
        })

        this._subListItem(childList)
        console.log(childList)

        let all = childList.length
        let online = 0

        if (!index) parentitem.active = true // 第一个展开
        parentitem.child = childList
        parentitem.numString = `[${online}/${all}]`

        return parentitem
      })

      return res
    },
    toggleChildList (selectitem) {
      let id = selectitem.gid

      this.parentGroupList.forEach(item => {
        if (item.gid === id) {
          item.active = !selectitem.active
        } else {
          item.active = false
        }
      })
    },
    _subListItem (list) {
      if (!list.length) return
      this.getSubItem(list)
    },
    getSubItem (list) {
      getMsList(list[this.itemIndex].gid, res => {
        if (res && res.code === '0') {
          let online = res.list.filter(item => { // 筛选上线数组
            return item.online === '1'
          })

          list[this.itemIndex].numString = `[${online.length}/${res.list.length}]`
          list[this.itemIndex].memberList = res.list

          if (this.itemIndex === list.length - 1) return
          this.itemIndex++
          this.getSubItem(list)
        }
      })
    }
  }
}
</script>

<style lang="stylus" scoped>
  .group-list-wrap
    padding 10px
    height 100%
    overflow-y auto
    background #ffffff
    ul li
      height 34px
      line-height 34px
      font-size 16px
      cursor pointer
      transition all 0.1s
      &.active
        i
          transform rotate(90deg)
      .item-info
        font-size 16px
        &:hover
          color #1a4687
    .name,.num
      padding-left 5px
</style>
