<template>
  <transition name='slide'>
      <div class="group-sub-wrap">
          <ul>
              <li v-for="(item) in list"
                  :key="item.gid" class="parent-item"
                  :class="{active: item.active}"
                  @click.stop="selecItem(list, item)">
                  <div class="item-info flex between">
                    <div class="left">
                      <i-icon type="ios-arrow-forward" />
                      <i-icon type="ios-people" size="24" color="#4990d7" />
                      <span class="name">{{item.name}}</span>
                    </div>
                    <span class="num">{{item.numString}}</span>
                  </div>
                  <member-list :list='item.memberList' v-if="item.active"/>
              </li>
          </ul>
      </div>
    </transition>
</template>

<script>
import { Icon } from 'iview'
// import { getMsList } from '@/sdkJs/webDispatch-sdk.js'
import MemberList from './group-member'
import { toggleChildList } from '@/utils/dom'

export default {
  name: 'GroupMenu',
  components: {
    'i-icon': Icon,
    MemberList
  },
  props: {
    childIndex: Number,
    list: Array
  },
  computed: {
    subList () {
      return this.$store.getters.groupList[this.childIndex].child
    }
  },
  data () {
    return {
      parentList: [],
      itemIndex: 0
    }
  },
  mounted () {
    // this._subListItem()
  },
  methods: {
    selecItem (list, item) {
      if (!item.memberList) {
        // this.$store.dispatch('_getMsList', {list, index: this.itemIndex, type: 'child'})
      }
      toggleChildList(list, item)
    }
  }
}
</script>

<style lang="stylus" scoped>
  .group-sub-wrap
    li
      line-height: 40px
      transition all .2s
      .item-info
        padding-left 15px
        .name
          width 110px
          overflow hidden
          text-overflow ellipsis
          white-space nowrap
          display inline-block
          vertical-align middle
        .num
          font-size 14px
      &.active
        .item-info
          background #ddeefd
          i.ivu-icon-ios-arrow-forward
            transform rotate(90deg)
      &:hover
        background #ffffff
  .slide-enter-active, .slide-leave-active
    transition all .2s ease
  .slide-enter
    transform: translateX(200px)
  .slide-leave-to
    transform: translateX(-200px)
</style>
