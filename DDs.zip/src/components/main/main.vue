<template>
  <div class="main-wrap">
    <i-layout :style="{height: '100%'}" class="main">
      <!-- 顶部 -->
      <i-header class="i-header">
        <header-bar />
      </i-header>

      <i-layout :style="{background: '#fff'}">
        <!-- 侧边 -->
        <i-sider :width='260' hide-trigger class="left-side">
          <i-layout :style="{height: '100%'}">
            <i-header class="tab-header">
              <tabs></tabs>
              <i-input placeholder="请输入" style="width: 238px; margin: 8px 12px">
              <i-icon type="ios-search" slot="suffix" />
            </i-input>
            </i-header>
            <i-content class="flex-item">
              <side-group></side-group>
            </i-content>
            <div class="sider-bottom">
              PTT空格
            </div>
          </i-layout>
        </i-sider>
        <i-content>
          <!-- 路由切换区域 -->
            <keep-alive>
              <router-view/>
            </keep-alive>
        </i-content>
      </i-layout>
    </i-layout>
  </div>
</template>

<script>
import { Layout, Header, Content, Sider, Input, Icon } from 'iview'
import HeaderBar from './header-bar'
import SideGroup from './side-group'
import Tabs from './tabs'

export default {
  name: 'Main',
  components: {
    'i-layout': Layout,
    'i-header': Header,
    'i-content': Content,
    'i-sider': Sider,
    'i-input': Input,
    'i-icon': Icon,
    HeaderBar,
    SideGroup,
    Tabs
  }
}
</script>

<style lang="stylus" scoped>
  @import '../../assets/styles/variable.styl'

  .main-wrap
    height 100%
    .i-header
      background: #fff
      boxShadow: 0 2px 3px 2px rgba(0,0,0,.02)
      padding: 0
      height: 80px
      marginBottom: 5px
    .left-side
      position relative
      padding-bottom 60px
      background #ffffff
      .sider-wrap
        height 100%
      .tab-header
        height auto
        padding 0
        background $color-theme-weight
      .sider-bottom
        position absolute
        bottom 0
        left 0
        height 60px
        background $color-theme-weight
        text-align center
        width 100%
        line-height 60px
        color #fff
</style>
