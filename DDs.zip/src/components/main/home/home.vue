<template>
    <div class="home-wrap">
        <i-layout :style="{height: '100%', background: '#ffffff'}">
          <i-content :style="{padding: '0 12px', overflow: 'hidden'}">
            <div class="con-top">
              <span>群组</span>
            </div>
            <i-layout :style="{height: '100%', background: '#ffffff'}" class="sdddd">
              <i-content :style="{display: 'flex', flexDirection: 'column'}" class="align-items">
                  <block-group/>
                  <group-member/>
                  <send-message/>
              </i-content>
              <i-sider :width="216" hide-trigger :style="{background: '#7da8e7', marginLeft: '3px'}">
                <right-side-group/>
              </i-sider>
            </i-layout>
          </i-content>

          <!-- 最侧边 -->
          <i-sider :width="250" hide-trigger :style="{background: '#f3f3f3'}">
            <div>我是侧边</div>
          </i-sider>
        </i-layout>
    </div>
</template>

<script>
import { Layout, Sider, Content, Header } from 'iview'
import BlockGroup from './block-group'
import GroupMember from './group-member'
import SendMessage from './send-message'
import RightSideGroup from './right-side-group'

export default {
  name: 'Home',
  components: {
    'i-layout': Layout,
    'i-header': Header,
    'i-content': Content,
    'i-sider': Sider,
    BlockGroup,
    GroupMember,
    SendMessage,
    RightSideGroup
  }
}
</script>

<style lang="stylus" scoped>
  @import '../../../assets/styles/variable.styl'

  .home-wrap
    height 100%
    .con-top
      background $color-theme-weight
      height 36px
      span
        background $color-theme-weight-d
        color #ffffff
        line-height 36px
        display inline-block
        padding 0 44px
</style>
