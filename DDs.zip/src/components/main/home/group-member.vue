<template>
  <div class="group-member-wrap">
    <ul class="clearfix">
      <li class="member-item fl">
        <div class="img-wrap flex align-center justify-center">
          <img src="../../../assets/App_offline_2x.png" alt="">
        </div>
        <div class="id">
          1021212
        </div>
      </li>
      <li class="member-item fl">
        <div class="img-wrap flex align-center justify-center">
          <img src="../../../assets/App_offline_2x.png" alt="">
        </div>
        <div class="id">
          1021212
        </div>
      </li>
      <li class="member-item fl">
        <div class="img-wrap flex align-center justify-center">
          <img src="../../../assets/App_offline_2x.png" alt="">
        </div>
        <div class="id">
          1021212
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'BlockGroup'
}
</script>

<style lang="stylus" scoped>
  @import '../../../assets/styles/variable.styl'

  .group-member-wrap
    background $color-theme
    height 100%
    flex 1
    padding 36px 26px
    .member-item
      width 110px
      height 74px
      box-shadow 0 0 3px 5px rgba(100, 139, 149, .2)
      border-radius 8px
      background #ffffff
      margin-right 20px
      text-align center
      .img-wrap
        margin 10px auto
      .id
        font-size 10px
        text-align center
</style>
