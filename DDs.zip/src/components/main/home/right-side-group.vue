<template>
  <div class="side-group-wrap">
    <card :style="{width: '180px', margin: '36px auto'}">
        <p slot="title" class="title">
           最近群组
        </p>
        <i-button class="btn">
          Recent Group
        </i-button>
    </card>
    <card :style="{width: '180px', margin: '36px auto'}">
        <p slot="title" class="title">
           快捷群组
        </p>
        <i-button  class="btn">
          Recent Group
        </i-button>
        <i-button  class="btn mt12">
          Recent Group
        </i-button>
    </card>
  </div>
</template>

<script>
import { Card, Button } from 'iview'

export default {
  name: 'SideGroup',
  components: {
    'Card': Card,
    'i-button': Button
  }
}
</script>

<style lang="stylus" scoped>
  @import '../../../assets/styles/variable.styl'

  .title
    text-align center
  .btn
    width 100%
    background $color-theme-btn
    color #ffffff
    &.mt12
      margin-top 12px
</style>
