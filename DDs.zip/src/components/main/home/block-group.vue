<template>
  <div class="block-group-wrap">
    <checkbox-group>
      <div class="fl group-item flex between">
        <div class="top flex">
          <checkbox label="">
          </checkbox>
          <div class="item-info">
            <div class="info-line title">
              <span>群组：</span>
              <span>测试一群</span>
            </div>
            <div class="info-line">
              <span>群组成员：</span>
              <span>180人</span>
            </div>
            <div class="info-line">
              <span>当前在线：</span>
              <span>18人</span>
            </div>
          </div>
        </div>

        <div class="bottom flex between align-center">
            <span class="id">ID: 1005678445</span>
            <icon type="ios-people" size="40" color="#4990d7"/>
        </div>
      </div>
    </checkbox-group>
    <checkbox-group>
      <div class="fl group-item flex between">
        <div class="top flex">
          <checkbox label="">
          </checkbox>
          <div class="item-info">
            <div class="info-line title">
              <span>群组：</span>
              <span>测试一群</span>
            </div>
            <div class="info-line">
              <span>群组成员：</span>
              <span>180人</span>
            </div>
            <div class="info-line">
              <span>当前在线：</span>
              <span>18人</span>
            </div>
          </div>
        </div>

        <div class="bottom flex between align-center">
            <span class="id">ID: 1005678445</span>
            <icon type="ios-people" size="40" color="#4990d7"/>
        </div>
      </div>
    </checkbox-group>
    <checkbox-group>
      <div class="fl group-item flex between">
        <div class="top flex">
          <checkbox label="">
          </checkbox>
          <div class="item-info">
            <div class="info-line title">
              <span>群组：</span>
              <span>测试一群</span>
            </div>
            <div class="info-line">
              <span>群组成员：</span>
              <span>180人</span>
            </div>
            <div class="info-line">
              <span>当前在线：</span>
              <span>18人</span>
            </div>
          </div>
        </div>

        <div class="bottom flex between align-center">
            <span class="id">ID: 1005678445</span>
            <icon type="ios-people" size="40" color="#4990d7"/>
        </div>
      </div>
    </checkbox-group>
    <checkbox-group>
      <div class="fl group-item flex between">
        <div class="top flex">
          <checkbox label="">
          </checkbox>
          <div class="item-info">
            <div class="info-line title">
              <span>群组：</span>
              <span>测试一群</span>
            </div>
            <div class="info-line">
              <span>群组成员：</span>
              <span>180人</span>
            </div>
            <div class="info-line">
              <span>当前在线：</span>
              <span>18人</span>
            </div>
          </div>
        </div>

        <div class="bottom flex between align-center">
            <span class="id">ID: 1005678445</span>
            <icon type="ios-people" size="40" color="#4990d7"/>
        </div>
      </div>
    </checkbox-group>
    <checkbox-group>
      <div class="fl group-item flex between">
        <div class="top flex">
          <checkbox label="">
          </checkbox>
          <div class="item-info">
            <div class="info-line title">
              <span>群组：</span>
              <span>测试一群</span>
            </div>
            <div class="info-line">
              <span>群组成员：</span>
              <span>180人</span>
            </div>
            <div class="info-line">
              <span>当前在线：</span>
              <span>18人</span>
            </div>
          </div>
        </div>

        <div class="bottom flex between align-center">
            <span class="id">ID: 1005678445</span>
            <icon type="ios-people" size="40" color="#4990d7"/>
        </div>
      </div>
    </checkbox-group>
  </div>
</template>

<script>
import { CheckboxGroup, Checkbox, Icon } from 'iview'
export default {
  name: 'BlockGroup',
  components: {
    'CheckboxGroup': CheckboxGroup,
    'Checkbox': Checkbox,
    'Icon': Icon
  }
}
</script>

<style lang="stylus" scoped>
  @import '../../../assets/styles/variable.styl'

  .block-group-wrap
    background $color-theme
    height 308px
    margin-bottom 3px
    padding-left 26px
    .group-item
      height 240px
      width 200px
      border-radius 12px
      background #ffffff
      margin 36px 22px 0 0
      box-shadow 0 0 3px 5px rgba(100, 139, 149, .2)
      padding 20px
      cursor pointer
      flex-direction column
      .title
        font-size 16px
        color #000000
      .info-line
        padding-bottom 16px
      .bottom
        .id
          font-size 12px
</style>
