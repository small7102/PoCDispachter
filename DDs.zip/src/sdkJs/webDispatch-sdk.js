import CryptoJS from 'crypto-js/crypto-js'
console.log(CryptoJS)
//webSocket
var webSocket = null;
//心跳
var HBInterval = null, timeout = 120 * 1000;
//登录回调
var loginResp = null, getLoginInterval;
//获取群组回调
var getGroupResp = null, getGroupInterval;
//获取成员回调
var getMsResp = null, getMsInterval;
//获取服务器回调
var getServerInfoResp = null, getServerInfoInterval;
//终端信息
var msId, msPwd, token;
//调度接口
var ajax = new XMLHttpRequest();
// var _url = 'http://192.168.5.222:803/ds';
var _url = 'http://di.pocradio.com:5080/ds';

//登录
function login(mid, pwd, callback) {
    getServerInfo(mid, function (data) {
        if (data.code != 0) {
            //执行回调方法
            if (callback && typeof(callback) === "function")
                callback(data);
            return;
        }

        var wip = '192.168.5.56', wPort = '8031';
        var sip = data.ip = '192.168.5.56', sPort = data.tport = '9988';

        //判断当前浏览器是否支持WebSocket
        if ('WebSocket' in window) {
            webSocket = new WebSocket("ws://" + wip + ":" + wPort + "/webSocket");
        }
        else {
            console.log('Not support webSocket');
        }

        //连接成功建立的回调方法
        webSocket.onopen = function (event) {
            //发送登录指令
            var map = {};
            map['cmd'] = 'LOGIN';
            map['ip'] = sip;
            map['port'] = sPort;
            map['mid'] = msId = mid;
            map['pwd'] = msPwd = pwd;
            webSocket.send(JSON.stringify(map));
        }

        //接收到消息的回调方法
        webSocket.onmessage = function (event) {
            var data = eval('(' + decrypt(event.data) + ')');
            doReceive(data);
        }

        //连接关闭的回调方法
        webSocket.onclose = function () {
            console.log("webSocket close");
        }

        //连接发生错误的回调方法
        webSocket.onerror = function () {
            console.log("webSocket error");
        }

        //监听窗口关闭事件，当窗口关闭时，主动去关闭websocket连接，防止连接还没断开就关闭窗口，server端会抛异常。
        window.onbeforeunload = function () {
            webSocket.close();
        }

        //返回结果定时器
        getLoginInterval = setInterval(function () {
            if (loginResp != null) {
                //清除定时器
                window.clearInterval(getLoginInterval);
                //执行回调方法
                if (callback && typeof(callback) === "function")
                    callback(loginResp);
                //清除结果
                loginResp = null;
            }
        }, 500);
    })
}

//维持心跳
function sendHB() {
    var map = {};
    map['cmd'] = 'HB';
    webSocket.send(JSON.stringify(map));
}

//切换群组
function swithGroup(gid) {
    var map = {};
    map['cmd'] = 'SWITCHGROP';
    map['gid'] = gid;
    webSocket.send(JSON.stringify(map));
}

//创建单呼

//创建临时群组
function createTempGroup(idCount, midOrGid) {
    var map = {};
    map['cmd'] = 'CREATETEMPGROUP';
    map['idCount'] = idCount;
    map['midOrGid'] = midOrGid;
    webSocket.send(JSON.stringify(map));
}

//解除临时群组
function removeTempGroup(type) {
    var map = {};
    map['cmd'] = 'REMOVETEMPGROUP';
    map['type'] = type;
    webSocket.send(JSON.stringify(map));
}

//通知

//处理接收信息
function doReceive(data) {
    switch (data.cmd) {
        case 'LOGIN':
            loginResp = data;
            if (data.code == 0) {
                HBInterval = setInterval(sendHB, timeout);
                getToken();
            }
            break;
        case 'HB':
            if (timeout != data.hb) {
                timeout = data.hb * 1000;
                window.clearInterval(HBInterval);
                HBInterval = setInterval(sendHB, timeout);
            }
            break;
        case 'SWITCHGROP':
            break;
    }
}

//获取token
function getToken() {
    ajax.send();
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4 && ajax.status == 200) {
            var data = eval("(" + ajax.responseText + ")");
            console.log(data)
            token = data.desc;
        }
    }
}

//获取群组列表
function getGroupList(callback) {
    ajax.open('get', _url + '/data/grps?auth=' + token + '&cid=' + msId);
    ajax.send();
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4 && ajax.status == 200) {
            var data = eval("(" + ajax.responseText + ")");
            getGroupResp = data;
        }
    }

    //返回结果定时器
    getGroupInterval = setInterval(function () {
        if (getGroupResp != null) {
            //清除定时器
            window.clearInterval(getGroupInterval);
            //执行回调方法
            if (callback && typeof(callback) === "function")
                callback(getGroupResp);
            //清除结果
            getGroupResp = null;
        }
    }, 500);
}

//获取成员列表
function getMsList(gid, callback) {
    // ajax.open('get', '/api/data/clients?auth=' + token + '&cid=' + msId + '&gid=' + gid);
    ajax.open('get', _url + '/data/clients?auth=' + token + '&cid=' + msId + '&gid=' + gid);
    ajax.send();
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4 && ajax.status == 200) {
            var data = eval("(" + ajax.responseText + ")");
            getMsResp = data;
        }
    }

    //返回结果定时器
    getMsInterval = setInterval(function () {
        if (getMsResp != null) {
            //清除定时器
            window.clearInterval(getMsInterval);
            //执行回调方法
            if (callback && typeof(callback) === "function")
                callback(getMsResp);
            //清除结果
            getMsResp = null;
        }
    }, 500);
}

//获取服务器信息
function getServerInfo(mid, callback) {
    ajax.open('get', _url + '/pub/login?uid=' + mid);
    ajax.send();
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4 && ajax.status == 200) {
            var data = eval("(" + ajax.responseText + ")");
            getServerInfoResp = data;
        }
    }

    //返回结果定时器
    getServerInfoInterval = setInterval(function () {
        if (getServerInfoResp != null) {
            //清除定时器
            window.clearInterval(getServerInfoInterval);
            //执行回调方法
            if (callback && typeof(callback) === "function")
                callback(getServerInfoResp);
            //清除结果
            getServerInfoResp = null;
        }
    }, 500);
}

//发送消息
function send() {
    var message = document.getElementById('text').value;
    if (webSocket != null)
        webSocket.send(message);
}

//关闭连接
function closeWebSocket() {
    if (webSocket != null) {
        webSocket.close();
        webSocket = null;
    }
}

//将消息显示在网页上
function setMessageInnerHTML(message) {
    document.getElementById('message').innerHTML += message + '<br/>';
}

//加密
function encrypt(msg) {
    var key = CryptoJS.enc.Utf8.parse("ZheShiYiGeMiYaoO");
    var srcs = CryptoJS.enc.Utf8.parse(msg);
    var encrypted = CryptoJS.AES.encrypt(srcs, key, {mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7});
    return encrypted.toString();
}

//解密
function decrypt(msg) {
    var key = CryptoJS.enc.Utf8.parse("ZheShiYiGeMiYaoO");
    var decrypt = CryptoJS.AES.decrypt(msg, key, {mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7});
    return CryptoJS.enc.Utf8.stringify(decrypt).toString();
}


export {
    login,
    getGroupList,
    getMsList
}