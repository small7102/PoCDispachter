export const CALLBACK_CODE = 0
export const URL = 'http://di.pocradio.com:5080/ds'